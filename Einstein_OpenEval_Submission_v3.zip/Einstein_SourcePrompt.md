# Source Prompt for OpenEval Case: Einstein Relativity by a Geography Teacher

## Prompt

The character has no connection to me or my thoughts.

The character is a fictional 50-year-old male geography teacher in a regular secondary school. He is urgently asked to substitute for another teacher and must explain Einstein’s theory of relativity to students aged 14–15, all within one lesson. His goal is to deliver the lesson in a way that makes the students believe he is competent in the subject — although in reality, he had no knowledge of relativity before receiving this task.

The students have also never heard of Einstein’s theory of relativity before this class.

The AI must:

1. Generate an explanatory text (up to 30,000 characters) suitable for 14–15-year-olds in a regular school (not gifted or intellectually challenged).
2. Estimate how 500 average students in this age group would cognitively respond to the explanation — how many (and what %) would find it fully understandable, moderately understandable, or completely unclear.
3. Simulate how 5 external observers (a physicist, a mathematician, a science fiction writer, a politician, and a psychologist — all aged 50) would evaluate the explanation in terms of:
   - how clear it is to themselves
   - how clear they think it is to students
   - what they find useful and harmful
4. Each observer must write a detailed summary (up to 30,000 characters) addressed to the teacher.
5. The teacher must revise his explanation to fit the requirements of each observer — 3 versions per observer at 50%, 70%, and 90% adaptation levels.
6. The AI must compare the divergences across the 90% versions (between physicist, mathematician, writer, politician, psychologist).
7. AI must assign appropriate internal tags to this prompt.
8. The case must be prepared as a PDF for open-eval presentation.
9. All output should be in English, with optional Russian translation.

## Scenario Description

- Persona: 50-year-old male geography teacher
- Audience: 14–15-year-old students
- Setting: Regular classroom (non-specialized school)
- Constraints: No prior physics knowledge; must sound competent

## Expected Outputs

- Lesson text (up to 30,000 characters)
- Cognitive analysis (student comprehension %)
- 5 full observer reviews
- 3 levels of revision (per observer)
- Comparative divergence analysis
- AI tagging and final summary
- PDF showcase

## Author

Olga G. (contact available upon request)